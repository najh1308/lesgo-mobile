import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sensors_plus/sensors_plus.dart';

import '../core/api_client.dart';
import '../core/app_settings.dart';
import '../core/session.dart';
import '../models/models.dart';
import '../services/bimbel_service.dart';
import '../services/location_service.dart';
import '../widgets/bimbel_card.dart';
import '../widgets/common.dart';
import '../widgets/pilih_lokasi.dart';
import 'main_shell.dart';
import '../core/personalisasi.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  UserLocation? _loc;
  List<Bimbel> _items = [];
  List<Bimbel> _untukmu = []; // rekomendasi sesuai personalisasi
  bool _loading = true;
  String? _error;
  final _cari = TextEditingController();

  // Sensor goyang (akselerometer): goyangkan HP untuk rekomendasi bimbel acak.
  StreamSubscription<UserAccelerometerEvent>? _sensor;
  DateTime _goyangTerakhir = DateTime.fromMillisecondsSinceEpoch(0);
  static const _batasGoyang = 14.0; // m/s², tanpa gravitasi

  @override
  void initState() {
    super.initState();
    _muat();
    ShellController.refresh.addListener(_muat);
    Personalisasi.i.addListener(_muat);
    LocationService.berubah.addListener(_muat); // lokasi diganti -> muat ulang
    _sensor =
        userAccelerometerEventStream(samplingPeriod: SensorInterval.uiInterval)
            .listen(
              _cekGoyang,
              onError: (_) {}, // perangkat tanpa sensor (mis. Chrome/emulator): fitur ketuk tetap jalan
              cancelOnError: true,
            );
  }

  @override
  void dispose() {
    ShellController.refresh.removeListener(_muat);
    Personalisasi.i.removeListener(_muat);
    LocationService.berubah.removeListener(_muat);
    _sensor?.cancel();
    _cari.dispose();
    super.dispose();
  }

  void _cekGoyang(UserAccelerometerEvent e) {
    // Hanya aktif saat Beranda sedang tampil.
    if (!mounted || ShellController.tab.value != 0) return;
    if (ModalRoute.of(context)?.isCurrent != true) return;
    final kuat = sqrt(e.x * e.x + e.y * e.y + e.z * e.z);
    final now = DateTime.now();
    if (kuat > _batasGoyang &&
        now.difference(_goyangTerakhir).inMilliseconds > 2500) {
      _goyangTerakhir = now;
      HapticFeedback.mediumImpact();
      _acak();
    }
  }

  Future<void> _muat() async {
    if (!mounted) return;
    setState(() {
      _loading = true;
      _error = null;
    });
    final loc = await LocationService.current();
    try {
      final hasil = await BimbelService.list(
        lat: loc.lat,
        lng: loc.lng,
        sort: 'terdekat',
        perPage: 5,
        cacheKey: 'home',
      );

      // ▼▼▼ BARIS BARU + setState yang diganti ▼▼▼
      final untukmu = await _muatUntukmu(loc);
      if (!mounted) return;
      setState(() {
        _loc = loc;
        _items = hasil;
        _untukmu = untukmu; // <- baris baru
        _loading = false;
      });
      // ▲▲▲ ----------------------------------- ▲▲▲
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() {
        _loc = loc;
        _error = e.message;
        _loading = false;
      });
    }
  }

  /// Mapel pilihan pengguna yang cocok dengan mapel bimbel ini.
  List<String> _mapelCocok(Bimbel b) {
    final m = b.mapel.toLowerCase();
    return Personalisasi.i.mapel
        .where((x) => m.contains(x.toLowerCase()))
        .toList();
  }

  /// Bimbel sesuai jenjang dan estimasi biaya, diurutkan menurut kecocokan mapel lalu rating.
  /// Bimbel sesuai jenjang dan estimasi biaya, diurutkan menurut kecocokan mapel lalu rating.
  Future<List<Bimbel>> _muatUntukmu(UserLocation loc) async {
    final p = Personalisasi.i;
    if (!p.aktif) return [];
    try {
      // Server hanya menerima satu jenjang per permintaan: ambil per jenjang lalu gabungkan.
      final daftarJenjang = p.jenjangSet.isEmpty
          ? <String?>[null]
          : p.jenjangSet.toList();
      Future<List<Bimbel>> ambil(int? hargaMax) async {
        final gabung = <int, Bimbel>{};
        for (final j in daftarJenjang) {
          final h = await BimbelService.list(
            lat: loc.lat,
            lng: loc.lng,
            jenjang: j,
            hargaMax: hargaMax,
            sort: 'rating',
            perPage: 30,
          );
          for (final b in h) {
            gabung[b.id] = b;
          }
        }
        return gabung.values.toList();
      }

      var hasil = await ambil(p.budgetMax);
      if (hasil.isEmpty && p.budgetMax != null) {
        // Tidak ada yang sesuai biaya: tampilkan tanpa batas harga daripada kosong.
        hasil = await ambil(null);
      }
      hasil.sort((a, b) {
        final c = _mapelCocok(b).length.compareTo(_mapelCocok(a).length);
        return c != 0 ? c : b.rating.compareTo(a.rating);
      });
      return hasil.take(5).toList();
    } on ApiException {
      return [];
    }
  }

  void _kePencarian({String? q, String? jenjang}) {
    ShellController.searchJenjang.value = jenjang;
    ShellController.searchQuery.value = q ?? '';
    ShellController.tab.value = 1;
  }

  Future<void> _favorit(Bimbel b) async {
    final baru = !b.isFavorit;
    setState(() => b.isFavorit = baru);
    try {
      await BimbelService.setFavorit(b.id, baru);
      ShellController.bump();
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() => b.isFavorit = !baru);
      showMsg(context, e.message, error: true);
    }
  }

  /// Rekomendasi kejutan: buka bimbel acak dari daftar terdekat.
  void _acak() {
    if (_items.isEmpty) {
      showMsg(context, 'Belum ada bimbel untuk direkomendasikan');
      return;
    }
    final b = _items[Random().nextInt(_items.length)];
    Navigator.pushNamed(context, '/detail', arguments: b.id);
  }

  String get _salam {
    final j = DateTime.now().hour;
    if (j < 11) return 'Selamat pagi,';
    if (j < 15) return 'Selamat siang,';
    if (j < 18) return 'Selamat sore,';
    return 'Selamat malam,';
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle
          .light, // ikon status bar putih di atas header biru
      child: Scaffold(
        backgroundColor: const Color(0xFFF8F9FA), // ubah warna latar halaman ini di sini
        body: RefreshIndicator(
          color: const Color(0xFF0F4C81),
          backgroundColor: Colors.white,
          onRefresh: _muat,
          edgeOffset: MediaQuery.paddingOf(context).top,
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              _hero(context),
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    _promo(),
                    const SizedBox(height: 26),
                    if (Personalisasi.i.aktif) ...[
                      _kartuProfil(),
                      const SizedBox(height: 26),
                      if (_untukmu.isNotEmpty) ...[
                        SectionTitle(
                          'Rekomendasi untukmu',
                          action: 'Lihat semua',
                          onAction: () =>
                              _kePencarian(jenjang: Personalisasi.i.jenjang),
                        ),
                        const SizedBox(height: 13),
                        _daftarUntukmu(),
                        const SizedBox(height: 26),
                      ],
                    ],

                    const SectionTitle('Pilih jenjangmu'),
                    const SizedBox(height: 13),
                    _jenjang(),
                    const SizedBox(height: 26),
                    _kartuGoyang(),
                    const SizedBox(height: 26),
                    SectionTitle(
                      'Bimbel terdekat',
                      action: 'Lihat semua',
                      onAction: () => _kePencarian(),
                    ),
                    const SizedBox(height: 13),
                    _daftarTerdekat(),
                    const SizedBox(height: 26),
                    const SectionTitle('Belajar sesuai caramu'),
                    const SizedBox(height: 13),
                    Row(
                      children: [
                        Expanded(
                          child: _Pintasan(
                            icon: Icons.smart_toy_outlined,
                            bg: const Color(0xFFEAF2F8),
                            fg: const Color(0xFF0F4C81),
                            judul: 'Chatbot Geo',
                            sub: 'Tanya materi apa saja',
                            onTap: () => Navigator.pushNamed(context, '/tutor'),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: _Pintasan(
                            icon: Icons.sports_esports_outlined,
                            bg: const Color(0xFFFFF1E6),
                            fg: const Color(0xFFCF6F29),
                            judul: 'Hitung Cepat',
                            sub: 'Main & latih fokusmu',
                            onTap: () => Navigator.pushNamed(context, '/game'),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _hero(BuildContext context) {
    final u = Session.user;
    final nama = (u?.nama ?? 'Teman').split(' ').first;
    return Container(
      padding: EdgeInsets.fromLTRB(
        18,
        MediaQuery.paddingOf(context).top + 16,
        18,
        20,
      ),
      decoration: const BoxDecoration(
        color: Color(0xFF0F4C81),
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(28)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              const Brand(light: true),
              const Spacer(),
              SquareIconButton(
                Icons.notifications_none_rounded,
                light: true,
                dot: true,
                tooltip: 'Jadwal & pengingat',
                onTap: () => ShellController.tab.value = 3,
              ),
            ],
          ),
          const SizedBox(height: 22),
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _salam,
                      style: TextStyle(
                        fontSize: 12.5,
                        color: Colors.white.withAlpha(200),
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Halo, $nama!',
                      style: const TextStyle(
                        fontSize: 25,
                        fontWeight: FontWeight.w800,
                        letterSpacing: -0.7,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 4),
                    // Ketuk untuk memilih lokasi lain (kota, peta, atau GPS).
                    GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: () => tampilPilihLokasi(context),
                      child: Row(
                        children: [
                          Icon(
                            Icons.location_on_outlined,
                            size: 15,
                            color: Colors.white.withAlpha(190),
                          ),
                          const SizedBox(width: 3),
                          Flexible(
                            child: Text(
                              _loc?.label ?? 'Mencari lokasi...',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontSize: 13,
                                color: Colors.white.withAlpha(190),
                              ),
                            ),
                          ),
                          const SizedBox(width: 2),
                          Icon(
                            Icons.keyboard_arrow_down_rounded,
                            size: 18,
                            color: Colors.white.withAlpha(190),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              GestureDetector(
                onTap: () => ShellController.tab.value = 4,
                child: Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: const Color(0xFFF4A261),
                    border: Border.all(
                      color: Colors.white.withAlpha(72),
                      width: 3,
                    ),
                    image: u?.foto == null
                        ? null
                        : DecorationImage(image: u!.foto!, fit: BoxFit.cover),
                  ),
                  alignment: Alignment.center,
                  child: u?.foto != null
                      ? null
                      : Text(
                          nama.isEmpty ? '?' : nama[0].toUpperCase(),
                          style: const TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 18,
                            color: Color(0xFF1D2A44),
                          ),
                        ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          Container(
            height: 50,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
            ),
            child: TextField(
              controller: _cari,
              textInputAction: TextInputAction.search,
              onSubmitted: (v) => _kePencarian(q: v.trim()),
              cursorColor: const Color(0xFF0F4C81),
              style: const TextStyle(fontSize: 14, color: Color(0xFF1D2A44)),
              decoration: InputDecoration(
                hintText: 'Cari bimbel, mapel, atau lokasi...',
                hintStyle: const TextStyle(color: Color(0xFF8590A0), fontSize: 14),
                border: InputBorder.none,
                enabledBorder: InputBorder.none,
                focusedBorder: InputBorder.none,
                filled: false,
                contentPadding: const EdgeInsets.symmetric(vertical: 15),
                prefixIcon: const Icon(
                  Icons.search_rounded,
                  color: Color(0xFF8590A0),
                  size: 21,
                ),
                suffixIcon: IconButton(
                  icon: const Icon(
                    Icons.arrow_forward_rounded,
                    color: Color(0xFF00A896),
                  ),
                  onPressed: () => _kePencarian(q: _cari.text.trim()),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _promo() {
    return Container(
      height: 148,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: const Color(0xFF1D2A44),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Stack(
        children: [
          Positioned(
            right: 14,
            bottom: -6,
            child: Transform.rotate(
              angle: 0.14,
              child: Container(
                width: 110,
                height: 130,
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Color(0xFF00A896), Color(0xFF0D7D76)],
                  ),
                  borderRadius: BorderRadius.vertical(top: Radius.circular(60)),
                ),
                child: Stack(
                  children: [
                    const Positioned(
                      top: 14,
                      left: 16,
                      child: Text(
                        'π',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                          color: Color(0xFFF4A261),
                        ),
                      ),
                    ),
                    const Positioned(
                      top: 40,
                      right: 12,
                      child: Text(
                        '✦',
                        style: TextStyle(fontSize: 16, color: Color(0xFFF4A261)),
                      ),
                    ),
                    Center(
                      child: Transform.rotate(
                        angle: -0.14,
                        child: const Text(
                          'A+',
                          style: TextStyle(
                            fontSize: 33,
                            fontWeight: FontWeight.w800,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 18, 140, 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Eyebrow('BELAJAR LEBIH DEKAT', icon: Icons.auto_awesome),
                const SizedBox(height: 10),
                const Text(
                  'Temukan bimbel terbaik\ndi sekitarmu',
                  style: TextStyle(
                    fontSize: 17.5,
                    fontWeight: FontWeight.w800,
                    height: 1.3,
                    color: Colors.white,
                  ),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: () => _kePencarian(),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        'Jelajahi sekarang',
                        style: TextStyle(
                          fontSize: 12.5,
                          fontWeight: FontWeight.w700,
                          color: Color(0xFF00A896),
                        ),
                      ),
                      Icon(
                        Icons.chevron_right_rounded,
                        size: 18,
                        color: Color(0xFF00A896),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _jenjang() {
    const data = [
      ('SD', 'Kelas 1–6'),
      ('SMP', 'Kelas 7–9'),
      ('SMA', 'Kelas 10–12 · TKA'),
    ];
    return Row(
      children: [
        for (var i = 0; i < data.length; i++) ...[
          if (i > 0) const SizedBox(width: 9),
          Expanded(
            child: Material(
              color: Personalisasi.i.jenjangSet.contains(data[i].$1)
                  ? const Color(0xFFE4F7F4)
                  : Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
                side: BorderSide(
                  color: Personalisasi.i.jenjangSet.contains(data[i].$1)
                      ? const Color(0xFF00A896)
                      : const Color(0xFFE6EBF0),
                ),
              ),
              child: InkWell(
                borderRadius: BorderRadius.circular(14),
                onTap: () => _kePencarian(jenjang: data[i].$1),
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                    vertical: 13,
                    horizontal: 4,
                  ),
                  child: Column(
                    children: [
                      Text(
                        data[i].$1,
                        style: const TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 15,
                          color: Color(0xFF0F4C81),
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        data[i].$2,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 10.5,
                          color: Color(0xFF6F7B8F),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ],
    );
  }

  Widget _kartuProfil() {
    return Panel(
      onTap: () => Navigator.pushNamed(context, '/personalisasi'),
      child: Row(
        children: [
          const IconBox(
            Icons.tune_rounded,
            bg: Color(0xFFE4F7F4),
            fg: Color(0xFF00A896),
            size: 40,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Dipersonalisasi untukmu',
                  style: TextStyle(
                    fontSize: 13.5,
                    fontWeight: FontWeight.w800,
                    color: Color(0xFF1D2A44),
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  Personalisasi.i.ringkasan,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 12,
                    color: Color(0xFF6F7B8F),
                    height: 1.35,
                  ),
                ),
              ],
            ),
          ),
          const Text(
            'Ubah',
            style: TextStyle(
              fontSize: 12.5,
              fontWeight: FontWeight.w700,
              color: Color(0xFF00A896),
            ),
          ),
        ],
      ),
    );
  }

  Widget _daftarUntukmu() {
    return ListenableBuilder(
      listenable: AppSettings.i,
      builder: (context, _) => Column(
        children: [
          for (var i = 0; i < _untukmu.length; i++)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: BimbelCard(
                bimbel: _untukmu[i],
                horizontal: i > 0,
                badge: _mapelCocok(_untukmu[i]).isEmpty
                    ? null
                    : 'Cocok: ${_mapelCocok(_untukmu[i]).first}',
                onTap: () => Navigator.pushNamed(
                  context,
                  '/detail',
                  arguments: _untukmu[i].id,
                ),
                onFavorit: () => _favorit(_untukmu[i]),
              ),
            ),
        ],
      ),
    );
  }

  Widget _kartuGoyang() {
    return Material(
      color: const Color(0xFFE4F7F4),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: Color(0xFFA8DCD5)),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: _acak,
        child: Padding(
          padding: const EdgeInsets.all(13),
          child: Row(
            children: [
              const IconBox(
                Icons.vibration_rounded,
                bg: Color(0xFF00A896),
                fg: Colors.white,
                size: 40,
              ),
              const SizedBox(width: 11),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Bingung pilih bimbel?',
                      style: TextStyle(
                        fontSize: 13.5,
                        fontWeight: FontWeight.w800,
                        color: Color(0xFF1D2A44),
                      ),
                    ),
                    SizedBox(height: 2),
                    Text(
                      'Goyangkan HP (atau ketuk) untuk rekomendasi kejutan',
                      style: TextStyle(fontSize: 11.5, color: Color(0xFF6F7B8F)),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(7),
                ),
                child: const Text(
                  'COBA',
                  style: TextStyle(
                    fontSize: 10.5,
                    fontWeight: FontWeight.w800,
                    color: Color(0xFF00A896),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _daftarTerdekat() {
    if (_loading) {
      return const Padding(
        padding: EdgeInsets.all(32),
        child: Center(child: CircularProgressIndicator(color: Color(0xFF00A896))),
      );
    }
    if (_error != null)
      return SizedBox(
        height: 260,
        child: ErrorView(message: _error!, onRetry: _muat),
      );
    if (_items.isEmpty) {
      return const SizedBox(
        height: 200,
        child: EmptyView(
          icon: Icons.search_off,
          text: 'Belum ada bimbel di sekitarmu',
        ),
      );
    }
    return ListenableBuilder(
      listenable: AppSettings.i,
      builder: (context, _) => Column(
        children: [
          for (var i = 0; i < _items.length; i++)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: BimbelCard(
                bimbel: _items[i],
                horizontal: i > 0,
                badge: i == 0 ? 'Paling dekat' : null,
                onTap: () => Navigator.pushNamed(
                  context,
                  '/detail',
                  arguments: _items[i].id,
                ),
                onFavorit: () => _favorit(_items[i]),
              ),
            ),
        ],
      ),
    );
  }
}

class _Pintasan extends StatelessWidget {
  final IconData icon;
  final Color bg, fg;
  final String judul, sub;
  final VoidCallback onTap;
  const _Pintasan({
    required this.icon,
    required this.bg,
    required this.fg,
    required this.judul,
    required this.sub,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: Color(0xFFE6EBF0)),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              IconBox(icon, bg: bg, fg: fg, size: 38),
              const SizedBox(width: 8),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      judul,
                      style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                        color: Color(0xFF1D2A44),
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      sub,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 10.5,
                        color: Color(0xFF6F7B8F),
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(
                Icons.chevron_right_rounded,
                size: 18,
                color: Color(0xFF6F7B8F),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
