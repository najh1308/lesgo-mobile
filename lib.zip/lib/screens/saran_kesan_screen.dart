import 'package:flutter/material.dart';

import '../core/api_client.dart';
import '../core/format.dart';
import '../widgets/common.dart';

class SaranKesanScreen extends StatefulWidget {
  const SaranKesanScreen({super.key});

  @override
  State<SaranKesanScreen> createState() => _SaranKesanScreenState();
}

class _SaranKesanScreenState extends State<SaranKesanScreen> {
  final _saran = TextEditingController();
  final _kesan = TextEditingController();
  List<Map<String, dynamic>> _riwayat = [];
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _muat();
  }

  @override
  void dispose() {
    _saran.dispose();
    _kesan.dispose();
    super.dispose();
  }

  Future<void> _muat() async {
    try {
      final data = await ApiClient.rpcAuth('api_saran_kesan_list') as List;
      if (mounted) setState(() => _riwayat = data.map((e) => Map<String, dynamic>.from(e)).toList());
    } on ApiException {
      // Riwayat bersifat tambahan; abaikan jika gagal dimuat.
    }
  }

  Future<void> _kirim() async {
    if (_saran.text.trim().isEmpty || _kesan.text.trim().isEmpty) {
      showMsg(context, 'Saran dan kesan wajib diisi', error: true);
      return;
    }
    setState(() => _loading = true);
    try {
      await ApiClient.rpcAuth('api_saran_kesan_kirim', {'p_saran': _saran.text.trim(), 'p_kesan': _kesan.text.trim()});
      _saran.clear();
      _kesan.clear();
      if (mounted) showMsg(context, 'Terima kasih, saran dan kesan terkirim');
      await _muat();
    } on ApiException catch (e) {
      if (mounted) showMsg(context, e.message, error: true);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA), // ubah warna latar halaman ini di sini
      appBar: AppBar(
        title: const Text('Saran & kesan'),
        backgroundColor: Colors.white,
        foregroundColor: const Color(0xFF1D2A44),
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: false,
        titleTextStyle: const TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.w800,
          color: Color(0xFF1D2A44),
        ),
        shape: const Border(bottom: BorderSide(color: Color(0xFFE6EBF0))),
      ),
      body: ListView(padding: const EdgeInsets.fromLTRB(20, 4, 20, 28), children: [
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: const Color(0xFF0F4C81), borderRadius: BorderRadius.circular(18)),
          child: const Row(children: [
            IconBox(Icons.rate_review_outlined, bg: Colors.white, fg: Color(0xFF0F4C81), size: 44),
            SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Eyebrow('MATA KULIAH'),
                SizedBox(height: 3),
                Text('Pemrograman Aplikasi Mobile',
                    style: TextStyle(fontSize: 15.5, fontWeight: FontWeight.w800, color: Colors.white)),
                SizedBox(height: 2),
                Text('Ceritakan saran dan kesanmu selama perkuliahan.',
                    style: TextStyle(fontSize: 12, color: Color(0xFFB9CAD9))),
              ]),
            ),
          ]),
        ),
        const SizedBox(height: 20),
        const Text('Saran', style: TextStyle(fontWeight: FontWeight.w700, color: Color(0xFF1D2A44))),
        const SizedBox(height: 6),
        AppField(controller: _saran, hint: 'Tulis saranmu', icon: Icons.lightbulb_outline, maxLines: 4),
        const SizedBox(height: 14),
        const Text('Kesan', style: TextStyle(fontWeight: FontWeight.w700, color: Color(0xFF1D2A44))),
        const SizedBox(height: 6),
        AppField(controller: _kesan, hint: 'Tulis kesanmu', icon: Icons.favorite_border, maxLines: 4),
        const SizedBox(height: 18),
        PrimaryButton(label: 'Kirim', onPressed: _kirim, loading: _loading),
        const SizedBox(height: 24),
        if (_riwayat.isNotEmpty) const SectionTitle('Riwayat'),
        const SizedBox(height: 8),
        for (final r in _riwayat)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Panel(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(Fmt.tanggalJam(r['created_at'].toString()),
                    style: const TextStyle(fontSize: 12, color: Color(0xFF6F7B8F))),
                const SizedBox(height: 6),
                Text('Saran: ${r['saran']}', style: const TextStyle(color: Color(0xFF1D2A44))),
                const SizedBox(height: 4),
                Text('Kesan: ${r['kesan']}', style: const TextStyle(color: Color(0xFF1D2A44))),
              ]),
            ),
          ),
      ]),
    );
  }
}
